MODEL (
  name hnm.sales_by_group_month,
  kind FULL,
  dialect duckdb
);

SELECT
  date_trunc('month', t_dat) AS month,
  a.product_group_name,
  COUNT(*) AS num_items,
  SUM(t.price) AS total_sales
FROM hnm.transactions t
JOIN hnm.articles a
  ON t.article_id = a.article_id
GROUP BY 1, 2
ORDER BY 1, total_sales DESC;
