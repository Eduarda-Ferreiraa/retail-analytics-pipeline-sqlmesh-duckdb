MODEL (
  name hnm.top10_customers_products,
  kind FULL,
  dialect duckdb
);

WITH top AS (
  SELECT customer_id
  FROM hnm.top10_customers
)
SELECT
  t.customer_id,
  t.article_id,
  a.prod_name,
  a.product_group_name,
  a.colour_group_name,
  COUNT(*) AS qty,
  SUM(t.price) AS total_spent,
  MIN(t.t_dat) AS first_buy_date,
  MAX(t.t_dat) AS last_buy_date
FROM hnm.transactions t
JOIN top
  ON t.customer_id = top.customer_id
JOIN hnm.articles a
  ON t.article_id = a.article_id
GROUP BY 1,2,3,4,5
ORDER BY total_spent DESC;
