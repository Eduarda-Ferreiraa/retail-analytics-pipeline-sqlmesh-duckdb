MODEL (
  name hnm.customer_profile,
  kind FULL,
  dialect duckdb
);

SELECT
  customer_id,
  COUNT(*) AS total_items,
  COUNT(DISTINCT article_id) AS distinct_articles,
  SUM(price) AS total_spent,
  AVG(price) AS avg_price,
  MIN(t_dat) AS first_purchase_date,
  MAX(t_dat) AS last_purchase_date
FROM hnm.transactions
WHERE t_dat >= DATE '2020-08-01'
GROUP BY customer_id;
