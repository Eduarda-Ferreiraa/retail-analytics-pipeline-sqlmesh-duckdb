MODEL (
  name hnm.top10_customers,
  kind FULL,
  dialect duckdb,
  audits (price_positive, ids_not_null)
);

SELECT
  customer_id,
  SUM(price) AS total_value,
  COUNT(*) AS total_items
FROM hnm.transactions
GROUP BY customer_id
ORDER BY total_value DESC
LIMIT 10;
