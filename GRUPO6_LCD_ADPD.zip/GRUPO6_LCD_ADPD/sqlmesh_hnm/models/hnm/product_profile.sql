MODEL (
  name hnm.product_profile,
  kind FULL,
  dialect duckdb
);

SELECT
  t.article_id,
  a.prod_name,
  a.product_type_name,
  a.product_group_name,
  a.colour_group_name,
  COUNT(*) AS num_items,
  SUM(t.price) AS total_sales,
  AVG(t.price) AS avg_price,
  MIN(t.t_dat) AS first_sale_date,
  MAX(t.t_dat) AS last_sale_date
FROM hnm.transactions t
JOIN hnm.articles a
  ON t.article_id = a.article_id
GROUP BY 1,2,3,4,5;
