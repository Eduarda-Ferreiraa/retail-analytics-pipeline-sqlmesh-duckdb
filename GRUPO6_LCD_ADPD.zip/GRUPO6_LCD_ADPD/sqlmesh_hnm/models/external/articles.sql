MODEL (
  name hnm.articles,
  kind VIEW,
  dialect duckdb
);

SELECT * FROM read_csv_auto('/home/eduarda_ad_ferreira/data/articles.csv');
