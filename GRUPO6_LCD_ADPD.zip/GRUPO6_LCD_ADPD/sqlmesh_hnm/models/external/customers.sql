MODEL (
  name hnm.customers,
  kind VIEW,
  dialect duckdb
);

SELECT * FROM read_csv_auto('/home/eduarda_ad_ferreira/data/customers.csv');
