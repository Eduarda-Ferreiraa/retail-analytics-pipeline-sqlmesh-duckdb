MODEL (
  name hnm.transactions,
  kind VIEW,
  dialect duckdb
);

SELECT * FROM read_csv_auto('/home/eduarda_ad_ferreira/data/transactions_train-2.csv');
