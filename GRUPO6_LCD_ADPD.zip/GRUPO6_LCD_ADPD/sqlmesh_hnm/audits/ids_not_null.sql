AUDIT (
  name ids_not_null,
  dialect duckdb
);

SELECT *
FROM hnm.transactions
WHERE customer_id IS NULL OR article_id IS NULL;
