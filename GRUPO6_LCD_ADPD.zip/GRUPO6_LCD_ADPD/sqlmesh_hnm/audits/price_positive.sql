AUDIT (
  name price_positive,
  dialect duckdb
);

SELECT *
FROM hnm.transactions
WHERE price IS NULL OR price <= 0;
