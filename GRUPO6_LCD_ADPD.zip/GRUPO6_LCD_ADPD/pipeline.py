#!/usr/bin/env python
# coding: utf-8

# In[2]:


# ============================================================
# 0) Setup (Python + DuckDB) + Views para evitar re-leitura
# ============================================================


import duckdb
import os

ARTICLES_CSV = "data/articles.csv"
CUSTOMERS_CSV = "data/customers.csv"
TRANSACTIONS_CSV = "data/transactions_train-2.csv"

# (opcional) sanity check
for f in [ARTICLES_CSV, CUSTOMERS_CSV, TRANSACTIONS_CSV]:
    if not os.path.exists(f):
        raise FileNotFoundError(f"Ficheiro não encontrado: {f}")

DB_PATH = os.getenv("DB_PATH", "data/hm.duckdb")
con = duckdb.connect(database=DB_PATH)


# Views: evita repetir read_csv_auto em todas as queries (menos I/O, mais performance)
con.execute(f"CREATE OR REPLACE VIEW articles     AS SELECT * FROM read_csv_auto('{ARTICLES_CSV}');")
con.execute(f"CREATE OR REPLACE VIEW customers    AS SELECT * FROM read_csv_auto('{CUSTOMERS_CSV}');")
con.execute(f"CREATE OR REPLACE VIEW transactions AS SELECT * FROM read_csv_auto('{TRANSACTIONS_CSV}');")

print("Views criadas: articles, customers, transactions")


# In[3]:


# ============================================================
# OBJETIVO 1) Data Understanding + Validação dos Dados
# ============================================================

# 1) Dimensão dos datasets
num_transactions = con.execute("SELECT COUNT(*) FROM transactions;").fetchone()[0]
num_customers = con.execute("SELECT COUNT(*) FROM customers;").fetchone()[0]
num_articles = con.execute("SELECT COUNT(*) FROM articles;").fetchone()[0]

# 2) Validação de valores inválidos e missing values
invalid_prices = con.execute("""
    SELECT COUNT(*)
    FROM transactions
    WHERE price IS NULL OR price <= 0
""").fetchone()[0]

null_dates = con.execute("""
    SELECT COUNT(*)
    FROM transactions
    WHERE t_dat IS NULL
""").fetchone()[0]

missing_ids = con.execute("""
    SELECT COUNT(*)
    FROM transactions
    WHERE customer_id IS NULL OR article_id IS NULL
""").fetchone()[0]

# 2.1) Extras valorizados: datas fora de intervalo / duplicados exatos
invalid_dates_range = con.execute("""
    SELECT COUNT(*)
    FROM transactions
    WHERE t_dat < DATE '2010-01-01' OR t_dat > CURRENT_DATE
""").fetchone()[0]

dup_rows = con.execute("""
    SELECT
      COUNT(*) - COUNT(DISTINCT
        customer_id || '-' ||
        CAST(article_id AS VARCHAR) || '-' ||
        CAST(t_dat AS VARCHAR) || '-' ||
        CAST(price AS VARCHAR) || '-' ||
        CAST(sales_channel_id AS VARCHAR)
      ) AS dup_rows
    FROM transactions
""").fetchone()[0]

# 3) Integridade referencial
invalid_customers = con.execute("""
    SELECT COUNT(*)
    FROM transactions t
    LEFT JOIN customers c ON t.customer_id = c.customer_id
    WHERE c.customer_id IS NULL
""").fetchone()[0]

invalid_articles = con.execute("""
    SELECT COUNT(*)
    FROM transactions t
    LEFT JOIN articles a ON t.article_id = a.article_id
    WHERE a.article_id IS NULL
""").fetchone()[0]

# 4) Resumo
print("========== Resumo da validação ==========")
print(f"Transações: {num_transactions}")
print(f"Clientes:   {num_customers}")
print(f"Artigos:    {num_articles}")
print("----------------------------------------")
print(f"Preços inválidos (NULL ou <=0): {invalid_prices}")
print(f"Datas nulas:                     {null_dates}")
print(f"IDs em falta:                    {missing_ids}")
print(f"Datas fora do intervalo:         {invalid_dates_range}")
print(f"Duplicados exatos (aprox.):      {dup_rows}")
print("----------------------------------------")
print(f"Transações sem cliente válido:   {invalid_customers}")
print(f"Transações sem artigo válido:    {invalid_articles}")
print("========================================")


# In[4]:


# ============================================================
# OBJETIVO 2) Caracterização de Clientes (customer_profile)
# - inclui: num_items, total_spent, num_transactions (proxy), recência reprodutível,
#          canal favorito, secção favorita
# ============================================================

# última data do dataset (recência reprodutível)
last_date = con.execute("SELECT MAX(t_dat) FROM transactions;").fetchone()[0]

con.execute(f"""
CREATE OR REPLACE TABLE customer_profile AS
WITH
base_metrics AS (
    SELECT
        customer_id,
        COUNT(*) AS num_items,
        SUM(price) AS total_spent,
        COUNT(DISTINCT t_dat) AS num_transactions  -- proxy simples (explicar no relatório)
    FROM transactions
    GROUP BY customer_id
),
recency AS (
    SELECT
        customer_id,
        MAX(t_dat) AS last_purchase_date,
        DATE_DIFF('day', MAX(t_dat), DATE '{last_date}') AS days_since_last_purchase
    FROM transactions
    GROUP BY customer_id
),
favorite_channel AS (
    SELECT customer_id, sales_channel_id
    FROM (
        SELECT
            customer_id,
            sales_channel_id,
            COUNT(*) AS cnt,
            ROW_NUMBER() OVER (
                PARTITION BY customer_id
                ORDER BY COUNT(*) DESC, sales_channel_id
            ) AS rn
        FROM transactions
        GROUP BY customer_id, sales_channel_id
    )
    WHERE rn = 1
),
favorite_department AS (
    SELECT customer_id, department_name
    FROM (
        SELECT
            t.customer_id,
            a.department_name,
            COUNT(*) AS cnt,
            ROW_NUMBER() OVER (
                PARTITION BY t.customer_id
                ORDER BY COUNT(*) DESC, a.department_name
            ) AS rn
        FROM transactions t
        JOIN articles a ON t.article_id = a.article_id
        GROUP BY t.customer_id, a.department_name
    )
    WHERE rn = 1
)
SELECT
    b.customer_id,
    b.num_items,
    b.num_transactions,
    b.total_spent,
    r.last_purchase_date,
    r.days_since_last_purchase,
    fc.sales_channel_id AS favorite_channel,
    fd.department_name AS favorite_department
FROM base_metrics b
JOIN recency r USING (customer_id)
JOIN favorite_channel fc USING (customer_id)
JOIN favorite_department fd USING (customer_id)
""")

# Export CSV
con.execute("""
COPY customer_profile
TO 'customer_profile.csv'
WITH (HEADER, DELIMITER ',')
""")

print("customer_profile criado e exportado -> customer_profile.csv")
print("Preview:", con.execute("SELECT * FROM customer_profile LIMIT 5;").fetchall())


# In[5]:


# ============================================================
# OBJETIVO 3) Caracterização de Produtos (product_profile)
# - inclui: métricas básicas, vendas por estação (pivot),
#          e cross-selling otimizado (Top N + deduplicação por cliente)
# ============================================================

N = 2000  # Top N artigos mais vendidos para tornar cross-selling exequível

# 1) Top N artigos mais vendidos (para limitar o cross-selling)
con.execute(f"""
CREATE OR REPLACE TABLE top_articles AS
SELECT article_id
FROM transactions
GROUP BY article_id
ORDER BY COUNT(*) DESC
LIMIT {N}
""")

# 2) Tabela reduzida para self-join (DEDUP por cliente/artigo para não inflacionar pares)
con.execute("""
CREATE OR REPLACE TABLE t_top AS
SELECT DISTINCT t.customer_id, t.article_id
FROM transactions t
JOIN top_articles a ON t.article_id = a.article_id
""")

# 3) Produto relacionado (mais comprado pelos mesmos clientes) dentro do Top N
con.execute("""
CREATE OR REPLACE TABLE related_products_top AS
SELECT article_id, related_article_id
FROM (
    SELECT
        t1.article_id,
        t2.article_id AS related_article_id,
        COUNT(*) AS cnt,
        ROW_NUMBER() OVER (
            PARTITION BY t1.article_id
            ORDER BY COUNT(*) DESC, t2.article_id
        ) AS rn
    FROM t_top t1
    JOIN t_top t2
      ON t1.customer_id = t2.customer_id
     AND t1.article_id <> t2.article_id
    GROUP BY t1.article_id, t2.article_id
)
WHERE rn = 1
""")

# 4) Métricas básicas por produto (em cima de TODAS as transações)
con.execute("""
CREATE OR REPLACE TABLE product_base_metrics AS
SELECT
    article_id,
    COUNT(*) AS num_items_sold,
    SUM(price) AS total_sales
FROM transactions
GROUP BY article_id
""")

# 5) Vendas por estação do ano
con.execute("""
CREATE OR REPLACE TABLE product_season_sales AS
SELECT
    article_id,
    CASE
        WHEN EXTRACT(month FROM t_dat) IN (12,1,2) THEN 'Winter'
        WHEN EXTRACT(month FROM t_dat) IN (3,4,5) THEN 'Spring'
        WHEN EXTRACT(month FROM t_dat) IN (6,7,8) THEN 'Summer'
        ELSE 'Autumn'
    END AS season,
    COUNT(*) AS num_items_sold_season,
    SUM(price) AS total_sales_season
FROM transactions
GROUP BY article_id, season
""")

# 6) Tabela final product_profile com pivot de estações
con.execute("""
CREATE OR REPLACE TABLE product_profile AS
WITH season_pivot AS (
    SELECT
        article_id,
        SUM(CASE WHEN season = 'Winter' THEN total_sales_season ELSE 0 END) AS sales_winter,
        SUM(CASE WHEN season = 'Spring' THEN total_sales_season ELSE 0 END) AS sales_spring,
        SUM(CASE WHEN season = 'Summer' THEN total_sales_season ELSE 0 END) AS sales_summer,
        SUM(CASE WHEN season = 'Autumn' THEN total_sales_season ELSE 0 END) AS sales_autumn
    FROM product_season_sales
    GROUP BY article_id
)
SELECT
    a.article_id,
    a.prod_name,
    a.product_type_name,
    a.product_group_name,
    a.department_name,
    a.colour_group_name,

    bm.num_items_sold,
    bm.total_sales,

    sp.sales_winter,
    sp.sales_spring,
    sp.sales_summer,
    sp.sales_autumn,

    rp.related_article_id
FROM articles a
JOIN product_base_metrics bm ON a.article_id = bm.article_id
LEFT JOIN season_pivot sp     ON a.article_id = sp.article_id
LEFT JOIN related_products_top rp ON a.article_id = rp.article_id
""")

# Export CSV
con.execute("""
COPY product_profile
TO 'product_profile.csv'
WITH (HEADER, DELIMITER ',')
""")

print("product_profile criado e exportado -> product_profile.csv")
print("Preview:", con.execute("SELECT * FROM product_profile LIMIT 5;").fetchall())


# In[6]:


# ============================================================
# OBJETIVO 4) Produtos comprados pelos 10 melhores clientes
# - Top10 por total gasto + descrição agregada dos artigos que compraram
# ============================================================

con.execute("""
CREATE OR REPLACE TABLE top10_customers AS
SELECT
  customer_id,
  SUM(price) AS total_spent,
  COUNT(*) AS num_items
FROM transactions
GROUP BY customer_id
ORDER BY total_spent DESC
LIMIT 10
""")

con.execute("""
CREATE OR REPLACE TABLE top10_customers_products AS
SELECT
  t.customer_id,
  t.article_id,
  a.prod_name,
  a.product_type_name,
  a.department_name,
  a.colour_group_name,
  COUNT(*) AS qty_bought,
  SUM(t.price) AS total_spent_on_article,
  MIN(t.t_dat) AS first_buy_date,
  MAX(t.t_dat) AS last_buy_date
FROM transactions t
JOIN top10_customers tc ON t.customer_id = tc.customer_id
JOIN articles a ON t.article_id = a.article_id
GROUP BY
  t.customer_id, t.article_id,
  a.prod_name, a.product_type_name, a.department_name, a.colour_group_name
ORDER BY t.customer_id, total_spent_on_article DESC
""")

# Export CSV
con.execute("""
COPY top10_customers
TO 'top10_customers.csv'
WITH (HEADER, DELIMITER ',')
""")
con.execute("""
COPY top10_customers_products
TO 'top10_customers_products.csv'
WITH (HEADER, DELIMITER ',')
""")

print("top10_customers exportado -> top10_customers.csv")
print("top10_customers_products exportado -> top10_customers_products.csv")
print("Preview top10_customers:", con.execute("SELECT * FROM top10_customers;").fetchall())
print("Preview top10_customers_products:", con.execute("SELECT * FROM top10_customers_products LIMIT 5;").fetchall())


# In[7]:


# ============================================================
# OBJETIVO 5) Desempenho temporal (items + valor) por:
# - cor (colour_group_name) por mês
# - categoria/grupo (product_group_name) por mês
# ============================================================

con.execute("""
CREATE OR REPLACE TABLE sales_by_colour_month AS
SELECT
  DATE_TRUNC('month', t.t_dat) AS month,
  a.colour_group_name,
  COUNT(*) AS num_items,
  SUM(t.price) AS total_sales
FROM transactions t
JOIN articles a ON t.article_id = a.article_id
GROUP BY month, a.colour_group_name
ORDER BY month, total_sales DESC
""")

con.execute("""
CREATE OR REPLACE TABLE sales_by_group_month AS
SELECT
  DATE_TRUNC('month', t.t_dat) AS month,
  a.product_group_name,
  COUNT(*) AS num_items,
  SUM(t.price) AS total_sales
FROM transactions t
JOIN articles a ON t.article_id = a.article_id
GROUP BY month, a.product_group_name
ORDER BY month, total_sales DESC
""")

# Export CSV
con.execute("""
COPY sales_by_colour_month
TO 'sales_by_colour_month.csv'
WITH (HEADER, DELIMITER ',')
""")
con.execute("""
COPY sales_by_group_month
TO 'sales_by_group_month.csv'
WITH (HEADER, DELIMITER ',')
""")

print("sales_by_colour_month exportado -> sales_by_colour_month.csv")
print("sales_by_group_month exportado  -> sales_by_group_month.csv")
print("Preview colour:", con.execute("SELECT * FROM sales_by_colour_month LIMIT 5;").fetchall())
print("Preview group:", con.execute("SELECT * FROM sales_by_group_month LIMIT 5;").fetchall())


# In[1]:


import sys
print(sys.executable)


# In[ ]:




